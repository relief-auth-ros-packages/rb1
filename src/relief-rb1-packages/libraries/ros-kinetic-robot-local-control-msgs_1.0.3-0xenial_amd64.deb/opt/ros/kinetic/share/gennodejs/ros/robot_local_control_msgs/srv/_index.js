
"use strict";

let EnterShowerPetition = require('./EnterShowerPetition.js')
let MovePetition = require('./MovePetition.js')
let StatusPetition = require('./StatusPetition.js')
let DockPetition = require('./DockPetition.js')
let LeaveShowerPetition = require('./LeaveShowerPetition.js')
let PickPetition = require('./PickPetition.js')
let GoToPetition = require('./GoToPetition.js')
let MissionCommandPetition = require('./MissionCommandPetition.js')
let Cancel = require('./Cancel.js')
let ChargePetition = require('./ChargePetition.js')
let SetControlState = require('./SetControlState.js')
let UnchargePetition = require('./UnchargePetition.js')
let SimpleGoToWithValidation = require('./SimpleGoToWithValidation.js')
let PlacePetition = require('./PlacePetition.js')

module.exports = {
  EnterShowerPetition: EnterShowerPetition,
  MovePetition: MovePetition,
  StatusPetition: StatusPetition,
  DockPetition: DockPetition,
  LeaveShowerPetition: LeaveShowerPetition,
  PickPetition: PickPetition,
  GoToPetition: GoToPetition,
  MissionCommandPetition: MissionCommandPetition,
  Cancel: Cancel,
  ChargePetition: ChargePetition,
  SetControlState: SetControlState,
  UnchargePetition: UnchargePetition,
  SimpleGoToWithValidation: SimpleGoToWithValidation,
  PlacePetition: PlacePetition,
};
