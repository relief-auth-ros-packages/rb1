
"use strict";

let ProcedureQuery = require('./ProcedureQuery.js')

module.exports = {
  ProcedureQuery: ProcedureQuery,
};
